<?php
        
        session_start();
        include ("connMySQL.php");
        
        //$id = 
        //$pid = 
        $content = $_POST['content'];
        $star = $_POST['star'];

        if(isset($_SESSION['member_id']))
        {
            $mid = $_SESSION['member_id'];
            if($content != NULL && $star != NULL)
            {
                $sql_id = "SELECT comment_id FROM comment WHERE comment_id >= ALL(SELECT comment_id FROM comment)"; 
                $result = $conn->query($sql_id);
                $row = $result->fetch_assoc();
                $id = $row["comment_id"] + 1;
                
                $pid = $_SESSION['product'];

                $sql = "INSERT INTO comment(comment_id,comment_pid,comment_content,comment_star,comment_mid) VALUES ('$id','$pid','$content','$star','$mid')"; 
                $result = $conn->query($sql);                
                
                
                if($result)
                {
                    echo '留言成功!';
                    echo "<meta http-equiv=REFRESH CONTENT=1;url=product.php?id=$pid>";
                    
                }
                else
                {
                    echo "留言失敗";
                    echo "<meta http-equiv=REFRESH CONTENT=1;url=product.php?id=$pid>";
                }

            }
            else
            {
                echo "未輸入留言及星等";
                echo "<meta http-equiv=REFRESH CONTENT=1;url=product.php?id=$pid>";
            }
        }
        else
        {
            echo "未登入，無法留言";
            echo '<meta http-equiv=REFRESH CONTENT=1;url=homelogin.html>';
            
        }
?>